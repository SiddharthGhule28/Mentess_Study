﻿namespace DapperCore_3._1.Dto
{
    public class CompanyForUpdateDto
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Country { get; set; }
        public int CafeId { get; set; }
    }
}
