﻿namespace DapperCore_3._1.Dto
{
    public class CompanyToCreate
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Country { get; set; }
    }
}
