﻿namespace DapperCore_3._1.Models
{
    public class Cafe
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ManagerName { get; set; }
    }
}
